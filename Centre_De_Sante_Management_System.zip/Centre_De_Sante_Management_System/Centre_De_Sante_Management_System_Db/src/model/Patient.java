/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author CYPHER
 */
public class Patient {
    private String Patient_No;
    private String First_Name;
    private String Last_Name;
    private String Phone_Number;
    private String Address;
    private String Insurance;

    public Patient() {
    }

    public Patient(String Patient_No, String First_Name, String Last_Name, String Phone_Number, String Address, String Insurance) {
        this.Patient_No = Patient_No;
        this.First_Name = First_Name;
        this.Last_Name = Last_Name;
        this.Phone_Number = Phone_Number;
        this.Address = Address;
        this.Insurance = Insurance;
    }

    public String getPatient_No() {
        return Patient_No;
    }

    public void setPatient_No(String Patient_No) {
        this.Patient_No = Patient_No;
    }

    public String getFirst_Name() {
        return First_Name;
    }

    public void setFirst_Name(String First_Name) {
        this.First_Name = First_Name;
    }

    public String getLast_Name() {
        return Last_Name;
    }

    public void setLast_Name(String Last_Name) {
        this.Last_Name = Last_Name;
    }

    public String getPhone_Number() {
        return Phone_Number;
    }

    public void setPhone_Number(String Phone_Number) {
        this.Phone_Number = Phone_Number;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getInsurance() {
        return Insurance;
    }

    public void setInsurance(String Insurance) {
        this.Insurance = Insurance;
    }
    
}
