/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author CYPHER
 */
public class Users {
    private String first_name;
    private String last_name;
    private String username;
    private String password;
    private String Retype_Password;

    public Users() {
    }

    public Users(String first_name, String last_name, String username, String password, String Retype_Password) {
        this.first_name = first_name;
        this.last_name = last_name;
        this.username = username;
        this.password = password;
        this.Retype_Password = Retype_Password;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRetype_Password() {
        return Retype_Password;
    }

    public void setRetype_Password(String Retype_Password) {
        this.Retype_Password = Retype_Password;
    }
    
}
