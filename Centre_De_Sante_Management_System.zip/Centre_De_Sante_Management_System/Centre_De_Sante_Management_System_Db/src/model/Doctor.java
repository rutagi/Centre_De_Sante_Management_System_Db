/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.*;

/**
 *
 * @author CYPHER
 */
public class Doctor {
    private String Doctor_No;
    private String First_Name;
    private String Last_Name;
    private String Phone_Number;
    private Date Schedule;
    public String getDoctor_No;

    public Doctor() {
    }

    public Doctor(String Doctor_No, String First_Name, String Last_Name, String Phone_Number, Date Schedule) {
        this.Doctor_No = Doctor_No;
        this.First_Name = First_Name;
        this.Last_Name = Last_Name;
        this.Phone_Number = Phone_Number;
        this.Schedule = Schedule;
    }

    public String getDoctor_No() {
        return Doctor_No;
    }

    public void setDoctor_No(String Doctor_No) {
        this.Doctor_No = Doctor_No;
    }

    public String getFirst_Name() {
        return First_Name;
    }

    public void setFirst_Name(String First_Name) {
        this.First_Name = First_Name;
    }

    public String getLast_Name() {
        return Last_Name;
    }

    public void setLast_Name(String Last_Name) {
        this.Last_Name = Last_Name;
    }

    public String getPhone_Number() {
        return Phone_Number;
    }

    public void setPhone_Number(String Phone_Number) {
        this.Phone_Number = Phone_Number;
    }

    public Date getSchedule() {
        return Schedule;
    }

    public void setSchedule(Date Schedule) {
        this.Schedule = Schedule;
    }
    
}
