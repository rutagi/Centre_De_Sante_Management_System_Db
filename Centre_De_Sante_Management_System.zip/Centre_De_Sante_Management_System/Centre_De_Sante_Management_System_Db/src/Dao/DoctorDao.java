/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import java.sql.*;
import model.Doctor;


/**
 *
 * @author CYPHER
 */
public class DoctorDao {
    
    private String dbURL="jdbc:postgresql://localhost:5432/Centre_De_Sante_Management_System_Db";
    private String dbUsername="postgres";
    private String dbPswd="josh";
    
    
    public String saveDooctor(Doctor doc) {
            try{
        //Register Driver
        DriverManager.registerDriver(new org.postgresql.Driver());
        
        //Create connection
        Connection conn = DriverManager.getConnection(dbURL,dbUsername,dbPswd);
        Statement st = conn.createStatement();
        String sql = "insert into doctor(doctor_no,first_name,last_name,phone_number,schedule) values('"+doc.getDoctor_No()+"','"+doc.getFirst_Name()+"','"+doc.getLast_Name()+"','"+doc.getPhone_Number()+"','"+doc.getSchedule()+"') ";
        
        //execute statement
        int numberOfRowsAffected =st.executeUpdate(sql);
        if(numberOfRowsAffected>=1){
            return "Data Saved Successfully";
            
            
        }
    }
    catch (Exception ex){
        ex.printStackTrace();
    }
    
    return "Data not Saved ";
    }
    
    
     public ResultSet getAllDoctor(){
        try{
             Connection conn = DriverManager.getConnection(dbURL,dbUsername,dbPswd);
        Statement st = conn.createStatement();
        String sql ="select * from Doctor";
        ResultSet result = st.executeQuery(sql);
        conn.close();
        return result;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return null;
    }
    
    
    public String updateDoctor(Doctor doc){
        try{
             
            //Register Driver
        DriverManager.registerDriver(new org.postgresql.Driver());
        
        //Create connection
        Connection conn = DriverManager.getConnection(dbURL,dbUsername,dbPswd);
        Statement st = conn.createStatement();
        String sql = "update doctor set first_name='"+doc.getFirst_Name()+"' ,last_name='"+doc.getLast_Name()+"' ,phone_number='"+
                doc.getPhone_Number()+"' ,schedule='"+
                doc.getSchedule()+"' where doctor_no='"+doc.getDoctor_No()+"'";
         
         //execute statement
        int numberOfRowsAffected =st.executeUpdate(sql);
        if(numberOfRowsAffected>=1){
            return "Data Updated Successfully";
        } 
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return "Data Not Updated Successfully";
    }

    
    
    
    
    public String deleteDoctor(Doctor doc){
        try{
             
            //Register Driver
        DriverManager.registerDriver(new org.postgresql.Driver());
        
        //Create connection
        Connection conn = DriverManager.getConnection(dbURL,dbUsername,dbPswd);
        Statement st = conn.createStatement();
         String sql ="delete from doctor where doctor_no='"+doc.getDoctor_No()+"'";
        
         //execute statement
        int numberOfRowsAffected =st.executeUpdate(sql);
        if(numberOfRowsAffected>=1){
            return "Data Deleted Successfully";
        } 
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return "Data Deleted Successfully";
    }
    
}

    
    

