/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import java.sql.*;
import model.*;

/**
 *
 * @author CYPHER
 */
public class PatientDAO {
    
    private String dbURL="jdbc:postgresql://localhost:5432/Centre_De_Sante_Management_System_Db";
    private String dbUsername="postgres";
    private String dbPswd="josh";
    
    
    public String savePatient(Patient patient){
    try{
        //Register Driver
        DriverManager.registerDriver(new org.postgresql.Driver());
        
        //Create connection
        Connection conn = DriverManager.getConnection(dbURL,dbUsername,dbPswd);
        Statement st = conn.createStatement();
        String sql = "insert into patient(patient_no,first_name,last_name,phone_number,address,insurance) values('"+patient.getPatient_No()+"','"+patient.getFirst_Name()+"','"+patient.getLast_Name()+"','"+patient.getPhone_Number()+"','"+patient.getAddress()+"','"+patient.getInsurance()+"') ";
        
        //execute statement
        int numberOfRowsAffected =st.executeUpdate(sql);
        if(numberOfRowsAffected>=1){
            return "Thank You For Registering";
            
        }
    }
    catch (Exception ex){
        ex.printStackTrace();
    }
    
    return "Data not Saved ";
    }
    
    public ResultSet getAllPatient(){
        try{
             Connection conn = DriverManager.getConnection(dbURL,dbUsername,dbPswd);
        Statement st = conn.createStatement();
        String sql ="select * from patient";
        ResultSet result = st.executeQuery(sql);
        conn.close();
        return result;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return null;
    }
    
    
    public String updatePatient(Patient patient){
        try{
            //Register Driver
        DriverManager.registerDriver(new org.postgresql.Driver());
        
        //Create connection
        Connection conn = DriverManager.getConnection(dbURL,dbUsername,dbPswd);
        Statement st = conn.createStatement();
        //String sql = "update patient set first_name='"+patient.getFirst_Name()+"' ,last_name='"+patient.getLast_Name()+"' ,phone_number='"+patient.getPhone_Number()+"' ,address='"+patient.getAddress()+"' ,insurance='"+patient.getInsurance()+"' where patient_no="+patient.getPatient_No();
        //String sql = "update patient set last_name='prince' where patient_no='23444'";
        //execute statement
        
        String sql = "update patient set first_name='"+patient.getFirst_Name()+"',last_name='"+patient.getLast_Name()+"',phone_number='"+
                patient.getPhone_Number()+"',address='"+patient.getAddress()+"',insurance='"+patient.getInsurance()+"' where patient_no='"+patient.getPatient_No()+"'";
        int numberOfRowsAffected =st.executeUpdate(sql);
        if(numberOfRowsAffected>=1){
            return "Data Updated Successfully";
        } 
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return "Data Not Updated";
    }
    
    
    public String deletePatient(Patient patient){
        try{
             
            //Register Driver
        DriverManager.registerDriver(new org.postgresql.Driver());
        
        //Create connection
        Connection conn = DriverManager.getConnection(dbURL,dbUsername,dbPswd);
        Statement st = conn.createStatement();
        String sql ="delete from patient where patient_no='"+patient.getPatient_No()+"'";
        
         //execute statement
        int numberOfRowsAffected =st.executeUpdate(sql);
        if(numberOfRowsAffected>=1){
            return "Data Deleted Successfully";
        } 
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return "Data Deleted Successfully";
    }
    
}
