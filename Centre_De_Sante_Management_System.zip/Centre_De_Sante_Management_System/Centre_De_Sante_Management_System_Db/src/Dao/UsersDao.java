/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import model.Users;

/**
 *
 * @author CYPHER
 */
public class UsersDao {
    String url="jdbc:postgresql://localhost:5432/Centre_De_Sante_Management_System Db";
    String username="postgres";
    String password="josh";
    
    
    public String saveUsers(Users user){
             try{
        //Register Driver
        DriverManager.registerDriver(new org.postgresql.Driver());
        
        //Create connection
        Connection conn = DriverManager.getConnection(url,username,password);
        Statement st = conn.createStatement();
        String sql = "insert into users (first_name,last_name,username,password) values ('"+user.getFirst_name()+"','"+user.getLast_name()+"','"+user.getUsername()+"','"+user.getPassword()+"')";
       
        //execute statement
        int numberOfRowsAffected =st.executeUpdate(sql);
        if(numberOfRowsAffected>=1){
            return "Data Saved Successfully";
        }
    }
    catch (Exception ex){
        ex.printStackTrace();
    }
    
    return "Data not Saved ";
    }
    
   public String retrieveUsers(Users user){
               try{
        //Register Driver
        DriverManager.registerDriver(new org.postgresql.Driver());
        
        //Create connection
        Connection conn = DriverManager.getConnection(url,username,password);
        Statement st = conn.createStatement();
        String sql = "select * from client where username='"+user.getUsername()+"' and password='"+user.getPassword()+"'";
       
        //execute statement
        int numberOfRowsAffected =st.executeUpdate(sql);
        if(numberOfRowsAffected>=1){
            return "Login Successfully";
        }
    }
    catch (Exception ex){
        ex.printStackTrace();
    }
    
    return "Login Failed ";
   }
    }

