package Service;

import Model.Patient;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface PatientService extends Remote{
   public String savePatient(Patient patient) throws RemoteException;
   public String updatePatient(Patient patient) throws RemoteException;
   public String deletePatient(Patient patient)throws RemoteException;
   public List retrieveAllPatient()throws RemoteException;
   public Patient getPatientBySearch(Patient patient) throws RemoteException;
}
