/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import Service.DoctorService;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;



/**
 *
 * @author CYPHER
 */
public class Doctor extends javax.swing.JFrame {

    /**
     * Creates new form Doctor
     */
    public Doctor() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        doctorNotxt = new javax.swing.JTextField();
        FNametxt = new javax.swing.JTextField();
        LNametxt = new javax.swing.JTextField();
        PNumbertxt = new javax.swing.JTextField();
        dateChoosertxt = new com.toedter.calendar.JDateChooser();
        DoctorBtn = new javax.swing.JButton();
        UpdateBtn = new javax.swing.JButton();
        DeleteBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Doctor's No");

        jLabel2.setText("First Name");

        jLabel3.setText("Last Name");

        jLabel4.setText("Phone Number");

        jLabel5.setText("Schedule");

        jLabel6.setText("Doctor's Registry");

        dateChoosertxt.setDateFormatString("MMM-dd-yyyy");

        DoctorBtn.setText("Save");
        DoctorBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DoctorBtnActionPerformed(evt);
            }
        });

        UpdateBtn.setText("Update ");
        UpdateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateBtnActionPerformed(evt);
            }
        });

        DeleteBtn.setText("Delete");
        DeleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel4)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel6)
                    .addComponent(doctorNotxt)
                    .addComponent(FNametxt)
                    .addComponent(LNametxt)
                    .addComponent(PNumbertxt)
                    .addComponent(dateChoosertxt, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE))
                .addGap(89, 89, 89))
            .addGroup(layout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addComponent(DoctorBtn)
                .addGap(32, 32, 32)
                .addComponent(UpdateBtn)
                .addGap(38, 38, 38)
                .addComponent(DeleteBtn)
                .addContainerGap(86, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(doctorNotxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(FNametxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(LNametxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(PNumbertxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(dateChoosertxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DoctorBtn)
                    .addComponent(UpdateBtn)
                    .addComponent(DeleteBtn))
                .addGap(21, 21, 21))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void DoctorBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DoctorBtnActionPerformed
       if(doctorNotxt.getText().isEmpty()||FNametxt.getText().isEmpty()||LNametxt.getText().isEmpty()||PNumbertxt.getText().isEmpty()){
       
           JOptionPane.showMessageDialog(this,"Please provide all data","Invalid",JOptionPane.ERROR_MESSAGE);
        }else if
            (doctorNotxt.getText().length()!=5){
                JOptionPane.showMessageDialog(this,"Doctor number must be 5 characters","Invalid",JOptionPane.ERROR_MESSAGE);
            }
        else if
            (PNumbertxt.getText().length()!=10){
                JOptionPane.showMessageDialog(this,"Phone number must be 10 digits","Invalid",JOptionPane.ERROR_MESSAGE);
            }else{
           try{
               Model.Doctor doctor = new Model.Doctor();
              Registry rgstry = LocateRegistry.getRegistry("127.0.0.1",5000);
              DoctorService intrf = (DoctorService)rgstry.lookup("doctor");
              // DoctorService ntrf = (DoctorService) registry.lookup("client");
               
               doctor.setDoctor_No(doctorNotxt.getText());
               doctor.setFirst_name(FNametxt.getText());
               doctor.setLast_name(LNametxt.getText());
               doctor.setPhone_Number(PNumbertxt.getText());
               //Date sqlDate= dateChoosertxt.getDate();
             
              doctor.setSchedule(dateChoosertxt.getDate()); 
              String feedback = intrf.saveDoctor(doctor);
              // String feedback = ntrf.saveDoctor(doctor);
               JOptionPane.showMessageDialog(null,feedback);

            doctorNotxt.setText("");
            FNametxt.setText("");
            LNametxt.setText("");
            PNumbertxt.setText("");
            dateChoosertxt.setDateFormatString("");
            
           }catch(Exception ex){
               ex.printStackTrace();
           }

       }
    }//GEN-LAST:event_DoctorBtnActionPerformed

    private void UpdateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateBtnActionPerformed

           try{
               Model.Doctor doctor = new Model.Doctor();
              Registry rgstry = LocateRegistry.getRegistry("127.0.0.1",5000);
              DoctorService intrf = (DoctorService)rgstry.lookup("doctor");
              // DoctorService ntrf = (DoctorService) registry.lookup("client");
               
               doctor.setDoctor_No(doctorNotxt.getText());
               doctor.setFirst_name(FNametxt.getText());
               doctor.setLast_name(LNametxt.getText());
               doctor.setPhone_Number(PNumbertxt.getText());
               doctor.setSchedule(dateChoosertxt.getDate());
               
              String feedback = intrf.updateDoctor(doctor);
              // String feedback = ntrf.saveDoctor(doctor);
               JOptionPane.showMessageDialog(null,feedback);
               
           }catch(Exception ex){
               ex.printStackTrace();
           }
    }//GEN-LAST:event_UpdateBtnActionPerformed

    private void DeleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteBtnActionPerformed
         try{
               Model.Doctor doctor = new Model.Doctor();
              Registry rgstry = LocateRegistry.getRegistry("127.0.0.1",5000);
              DoctorService intrf = (DoctorService)rgstry.lookup("doctor");
              // DoctorService ntrf = (DoctorService) registry.lookup("client");
               
               doctor.setDoctor_No(doctorNotxt.getText());
               doctor.setFirst_name(FNametxt.getText());
               doctor.setLast_name(LNametxt.getText());
               doctor.setPhone_Number(PNumbertxt.getText());
               doctor.setSchedule(dateChoosertxt.getDate());
               
              String feedback = intrf.deleteDoctor(doctor);
              // String feedback = ntrf.saveDoctor(doctor);
               JOptionPane.showMessageDialog(null,feedback);

           }catch(Exception ex){
               ex.printStackTrace();
           }
    }//GEN-LAST:event_DeleteBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Doctor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Doctor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Doctor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Doctor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Doctor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton DeleteBtn;
    private javax.swing.JButton DoctorBtn;
    private javax.swing.JTextField FNametxt;
    private javax.swing.JTextField LNametxt;
    private javax.swing.JTextField PNumbertxt;
    private javax.swing.JButton UpdateBtn;
    private com.toedter.calendar.JDateChooser dateChoosertxt;
    private javax.swing.JTextField doctorNotxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    // End of variables declaration//GEN-END:variables

    Date getSchedule() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
