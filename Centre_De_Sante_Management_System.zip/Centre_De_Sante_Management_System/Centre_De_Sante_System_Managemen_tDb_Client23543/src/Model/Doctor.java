/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;
import java.util.*;

/**
 *
 * @author CYPHER
 */

public class Doctor implements Serializable{
    private static final long serialVersionUID = 1234567890L;  // Specify a unique value.

  
    private String Doctor_No;
    private String First_name;
    private String Last_name;
    private String Phone_Number;
    private Date Schedule;
  

    public Doctor() {
    }

    public Doctor(String Doctor_No, String First_name, String Last_name, String Phone_Number, Date Schedule) {
        this.Doctor_No = Doctor_No;
        this.First_name = First_name;
        this.Last_name = Last_name;
        this.Phone_Number = Phone_Number;
        this.Schedule = Schedule;
    }

    public String getDoctor_No() {
        return Doctor_No;
    }

    public void setDoctor_No(String Doctor_No) {
        this.Doctor_No = Doctor_No;
    }

    public String getFirst_name() {
        return First_name;
    }

    public void setFirst_name(String First_name) {
        this.First_name = First_name;
    }

    public String getLast_name() {
        return Last_name;
    }

    public void setLast_name(String Last_name) {
        this.Last_name = Last_name;
    }

    public String getPhone_Number() {
        return Phone_Number;
    }

    public void setPhone_Number(String Phone_Number) {
        this.Phone_Number = Phone_Number;
    }

    public Date getSchedule() {
        return Schedule;
    }

    public void setSchedule(Date Schedule) {
        this.Schedule = Schedule;
    }
    
}
