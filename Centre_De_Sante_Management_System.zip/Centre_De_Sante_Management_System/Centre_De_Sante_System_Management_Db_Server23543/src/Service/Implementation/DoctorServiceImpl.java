/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service.Implementation;

import Dao.DoctorDao;
import Model.Doctor;
import Service.DoctorService;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;

/**
 *
 * @author CYPHER
 */
public class DoctorServiceImpl extends UnicastRemoteObject implements DoctorService{
    
    public DoctorServiceImpl() throws RemoteException{
        super();
    }
    
    
    private DoctorDao dao = new DoctorDao();
    @Override
    public String saveDoctor(Doctor doctor) throws RemoteException {
        try{
            dao.saveDoctor(doctor);
            return "Data Saved ";
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return "Data Not Saved";
    }

    @Override
    public String updateDoctor(Doctor doctor) throws RemoteException {
       try{
            dao.updateDoctor(doctor);
            return "Data Updated ";
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return "Data Not Updated"; 
    }

    @Override
    public String deleteDoctor(Doctor doctor) throws RemoteException {
        try{
            dao.deleteDoctor(doctor);
            return "Data Deleted";
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return "Data Not Deleted";
    }

    @Override
    public List<Doctor> retrieveAllDoctor() throws RemoteException {
        try{
            return dao.retrieveDoctor();
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return null;
        
    }
    
}
