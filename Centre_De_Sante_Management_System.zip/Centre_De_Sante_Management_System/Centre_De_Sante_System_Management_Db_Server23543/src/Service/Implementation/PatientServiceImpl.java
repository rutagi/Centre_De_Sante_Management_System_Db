/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service.Implementation;

import Dao.PatientDao;
import Model.Patient;
import Service.PatientService;
import java.rmi.RemoteException;

/**
 *
 * @author CYPHER
 */
public class PatientServiceImpl implements PatientService{
    private PatientDao dao = new PatientDao();

    @Override
    public String savePatient(Patient patient) throws RemoteException {
        try{
            dao.savePatient(patient);
            return "Data Saved ";
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return "Data Not Saved";
    }

    @Override
    public String updatePatient(Patient patient) throws RemoteException {
        try{
            dao.updatePatient(patient);
            return "Data Updated ";
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return "Data Not Updated";
    }

    @Override
    public String deletePatient(Patient patient) throws RemoteException {
        try{
            dao.deletePatient(patient);
            return "Data Deleted";
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return "Data Not Deleted";
    }

    @Override
    public String retrieveAllPatient(Patient patient) throws RemoteException {
    try{
            dao.retrieveAllPatient();
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return "";
    }
    
}
