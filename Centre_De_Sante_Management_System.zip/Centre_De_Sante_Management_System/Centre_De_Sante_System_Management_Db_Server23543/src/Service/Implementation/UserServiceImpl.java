/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service.Implementation;

import Dao.UserDao;
import Model.User;
import Service.UserService;
import java.rmi.RemoteException;

/**
 *
 * @author CYPHER
 */
public class UserServiceImpl implements UserService{

    private UserDao dao = new UserDao();

    @Override
    public String registerUsers(User user) throws RemoteException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String retrieveAllUsers(User user) throws RemoteException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
