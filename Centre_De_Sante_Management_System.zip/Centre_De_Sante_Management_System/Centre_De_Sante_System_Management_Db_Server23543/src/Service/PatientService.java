/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Model.Patient;
import java.rmi.RemoteException;

/**
 *
 * @author CYPHER
 */
public interface PatientService {
    String savePatient(Patient patient) throws RemoteException;
    String updatePatient(Patient patient) throws RemoteException;
    String deletePatient(Patient patient) throws RemoteException;
    String retrieveAllPatient(Patient patient) throws RemoteException;
    
}
