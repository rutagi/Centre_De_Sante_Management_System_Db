/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Model.Doctor;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

/**
 *
 * @author CYPHER
 */
public interface DoctorService extends Remote{
    String saveDoctor(Doctor doctor) throws RemoteException;
    String updateDoctor(Doctor doctor) throws RemoteException;
    String deleteDoctor(Doctor doctor) throws RemoteException;
    List<Doctor> retrieveAllDoctor() throws RemoteException;

}
