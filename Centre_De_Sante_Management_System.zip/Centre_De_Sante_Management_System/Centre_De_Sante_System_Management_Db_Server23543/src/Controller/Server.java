/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Service.Implementation.DoctorServiceImpl;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author CYPHER
 */
public class Server extends UnicastRemoteObject{
    
//   private DoctorServiceImpl doctorImpl;
//    
    public Server()throws RemoteException{
//       this.doctorImpl = new DoctorServiceImpl();
   }
    public static void main(String[] args) {
         try {
         System.setProperty("java.rmi.server.hostname","127.0.0.1");
         Registry registry = LocateRegistry.createRegistry(5000);
         registry.rebind("doctor",new DoctorServiceImpl());
             System.out.println("The server is running on port 5000");
        } catch (Exception ex) {
             ex.printStackTrace();
        }
         
    }
}
