/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import javax.persistence.*;

/**
 *
 * @author CYPHER
 */
@Entity
public class Patient {
    @Id
    @Column(name="Doctor No")
    private String Patient_No;
    @Column(name="first Name")
    private String first_name;
    @Column(name="Last Name")
    private String last_name;
    @Column(name="Phone Number")
    private String phone_number;
    private String Address;
    private String Insurance;

    public Patient() {
    }

    public Patient(String Patient_No) {
        this.Patient_No = Patient_No;
    }

    public Patient(String Patient_No, String first_name, String last_name, String phone_number, String Address, String Insurance) {
        this.Patient_No = Patient_No;
        this.first_name = first_name;
        this.last_name = last_name;
        this.phone_number = phone_number;
        this.Address = Address;
        this.Insurance = Insurance;
    }

    public String getPatient_No() {
        return Patient_No;
    }

    public void setPatient_No(String Patient_No) {
        this.Patient_No = Patient_No;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getInsurance() {
        return Insurance;
    }

    public void setInsurance(String Insurance) {
        this.Insurance = Insurance;
    }
    
}
