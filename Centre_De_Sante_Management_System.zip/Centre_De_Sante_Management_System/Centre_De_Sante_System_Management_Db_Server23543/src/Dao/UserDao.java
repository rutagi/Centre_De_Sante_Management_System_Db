/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.User;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author CYPHER
 */
public class UserDao {
    public void registerUsers(User user){
        try{
            Session ss =HibernateUtil.getSessionFactory().openSession();
            Transaction tr = ss.beginTransaction();
            ss.save(user);
            tr.commit();
            ss.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
      public List<User> retrieveAllUsers(){
          try{
          Session ss = HibernateUtil.getSessionFactory().openSession();
          List<User> userList = ss.createQuery("select user from Users user").list();
          ss.close();
          return userList;
      }catch(Exception ex){
          ex.printStackTrace();
      }
        return null;
    }
}
