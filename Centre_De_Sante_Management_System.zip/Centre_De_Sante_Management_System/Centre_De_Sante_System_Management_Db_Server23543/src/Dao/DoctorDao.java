/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.Doctor;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author CYPHER
 */
public class DoctorDao {
    public void saveDoctor(Doctor doctor){
        try{
           Session ss = HibernateUtil.getSessionFactory().openSession();
            Transaction tr = ss.beginTransaction();
            ss.save(doctor);
            tr.commit();
            ss.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
     public void updateDoctor(Doctor doctor){
        try{
           Session ss = HibernateUtil.getSessionFactory().openSession();
            Transaction tr = ss.beginTransaction();
            ss.update(doctor);
            tr.commit();
            ss.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
     
      public void deleteDoctor(Doctor doctor){
        try{
           Session ss = HibernateUtil.getSessionFactory().openSession();
            Transaction tr = ss.beginTransaction();
            ss.delete(doctor);
            tr.commit();
            ss.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
      
       public List<Doctor> retrieveDoctor(){
        try{
           Session ss = HibernateUtil.getSessionFactory().openSession();
            List<Doctor> doctorList = ss.createQuery("select doctor from Doctor doctor").list();
            ss.close();            
            return doctorList;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return null;
    }
}
