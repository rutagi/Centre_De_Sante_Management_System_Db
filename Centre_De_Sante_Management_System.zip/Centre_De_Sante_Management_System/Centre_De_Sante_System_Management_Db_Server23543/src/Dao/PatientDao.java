/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.Patient;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author CYPHER
 */
public class PatientDao {
    public void savePatient(Patient patient){
        try{
            Session ss =HibernateUtil.getSessionFactory().openSession();
            Transaction tr = ss.beginTransaction();
            ss.save(patient);
            tr.commit();
            ss.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
     public void updatePatient(Patient patient){
        try{
            Session ss =HibernateUtil.getSessionFactory().openSession();
            Transaction tr = ss.beginTransaction();
            ss.update(patient);
            tr.commit();
            ss.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
      public void deletePatient(Patient patient){
        try{
            Session ss =HibernateUtil.getSessionFactory().openSession();
            Transaction tr = ss.beginTransaction();
            ss.delete(patient);
            tr.commit();
            ss.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
      public List<Patient> retrieveAllPatient(){try{
          Session ss = HibernateUtil.getSessionFactory().openSession();
          List<Patient> doctotList = ss.createQuery("select patient from Patient patient").list();
          ss.close();
          return doctotList;
      }catch(Exception ex){
          ex.printStackTrace();
      }
        return null;
    }
   
}
